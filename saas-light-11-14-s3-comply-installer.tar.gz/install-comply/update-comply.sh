#!/bin/bash
if [[ $1 != "core" ]] && [[ $1 != "selenium" ]];
    then echo "This install script must be run with one argument which must be either "core" or "selenium".";
        exit 1;
    else


        case "$1" in
        "core" )
                 #mkdir /opt/worldspace
                 #cp scripts/components/install.options.core /opt/install.options
                 #cp -Ra ./scripts/components/sslcerts /opt
                 #cp ./scripts/comply-qa-centos-core.run /opt
                 #echo "Retreiving comply install.options from s3.."
                 echo "copying install.options from /opt.."
                 cp /opt/install.options ./
                 echo "Uninstalling comply core..."
                 ./opt/worldspace/uninstall
                 rm -rf /opt/worldspace
                # aws s3 cp s3://comply-ci/install.options.core ./install.options
                 cp ./install.options /opt
                 cd /opt;
                 echo "Retreiving comply bitrock installer from s3.."
                 aws s3 cp s3://comply-ci/comply-qa-centos-core.run ./comply-qa-centos-core.run
                 chmod 755 ./comply-qa-centos-core.run
                 echo "------------------- Executing comply-qa-centos-core.run"
                 echo "----------------------------------------------------"
                 ./comply-qa-centos-core.run --mode unattended --optionfile ./install.options
                 echo "------------------- Executing ./worldspace/bin/db_upgrade.sh"
                 echo "------------------------------------------------------------"
                 ./worldspace/bin/db_upgrade.sh
                 #sed -i 's-^/opt/worldspace/components/keycloak/bin/standalone.sh-nohup /opt/worldspace/components/keycloak/bin/standalone.sh-g' /opt/worldspace/components/keycloak/bin/firstrun.sh
                 #sed -i 's/OVERWRITE_EXISTING$/OVERWRITE_EXISTING \&/g' /opt/worldspace/components/keycloak/bin/firstrun.sh
                 #echo "------------------- Executing ./worldspace/components/keycloak/bin/firstrun.sh"
                 #echo "------------------------------------------------------------------------------"
                 chown -R worldspace:worldspace /opt/worldspace
                 #./worldspace/components/keycloak/bin/firstrun.sh > /dev/null &
                 cd -;
                 echo "------------------- Executing /etc/supervisord.d/comply.ini edits... ---------"
                 echo "------------------------------------------------------------------------------"
                 cat scripts/components/core-init-edit.txt | while read p n; do sed -i "/$p/,+$n"d"" /etc/supervisord.d/comply.ini; done
                 sed -i 's/autostart=false/autostart=true/g' /etc/supervisord.d/comply.ini
                 echo "------------------ Check supervisorctl service status ------------------------"
                 echo "------------------------------------------------------------------------------"
                 supervisorctl reload
                 supervisorctl status
                 sed -i 's.7/custom-rules.7.g' /opt/worldspace/mounts/nginx/conf.d/comply.conf
                 systemctl restart nginx
                 chown -R worldspace:worldspace /opt/worldspace
                 #redis-cli CONFIG SET dir /var/lib/redis
                 #redis-cli CONFIG SET dbfilename temp.rdb
                 #redis-cli BGSAVE
                 #echo "vm.overcommit_memory = 1" >> /etc/sysctl.conf
                 #sysctl vm.overcommit_memory=1
#                 ./start_order.sh core
                 ;;

        "selenium" )
#                     mkdir /opt/worldspace
#                     cp scripts/components/install.options.selenium /opt/install.options
                     #cp -Ra ./scripts/components/sslcerts /opt
#                     cp ./scripts/comply-qa-centos-core.run /opt
                     echo "copying install.options from /opt.."
                     cp /opt/install.options ./
                     echo "Uninstalling comply core..."
                     ./opt/worldspace/uninstall
                     rm -rf /opt/worldspace
                     cp ./install.options /opt
                     cd /opt;
                     #echo "Retreiving comply install.options from s3.."
                     #aws s3 cp s3://comply-ci/install.options.selenium ./install.options
                     echo "Retreiving comply bitrock installer from s3.."
                     aws s3 cp s3://comply-ci/comply-qa-centos-core.run ./comply-qa-centos-core.run
                     chmod 755 ./comply-qa-centos-core.run
                     echo "------------------- Executing comply-qa-centos-core.run"
                     echo "----------------------------------------------------"
                     ./comply-qa-centos-core.run --mode unattended --optionfile ./install.options
#                     ./worldspace/bin/db_upgrade.sh
#                     ./worldspace/components/keycloak/bin/firstrun.sh
                     chown -R worldspace:worldspace /opt/worldspace
                     cd -;
                     echo "------------------- Executing /etc/supervisord.d/comply.ini edits..."
                     echo "------------------------------------------------------------------------------"
                     cat scripts/components/selenium-init-edit.txt | while read p n; do sed -i "/$p/,+$n"d"" /etc/supervisord.d/comply.ini; done
                     sed -i 's/autostart=false/autostart=true/g' /etc/supervisord.d/comply.ini
                     echo "------------------ Check supervisorctl service status ------------------------"
                     echo "------------------------------------------------------------------------------"
                     supervisorctl reload
                     supervisorctl status
                     chown -R worldspace:worldspace /opt/worldspace
                     echo "vm.overcommit_memory = 1" >> /etc/sysctl.conf
                     sysctl vm.overcommit_memory=1
 #                    start_order.sh selenium
                     ;;
        esac

fi

