#!/bin/bash
if [[ $1 != "core" ]] && [[ $1 != "selenium" ]];
    then echo "This install script must be run with one argument which must be either "core" or "selenium".";
        exit 1;
    else


        case "$1" in
        "core" )
                 mkdir /opt/worldspace
                 #cp scripts/components/install.options.core /opt/install.options
                 
                 cp -Ra ./scripts/components/sslcerts /opt
                 #cp ./scripts/comply.linux-6.2.1.run /opt
                 cd /opt;
                 echo "Retreiving comply install.options from s3.."
                 aws s3 cp s3://comply-ci/install.options.core ./install.options
                 echo "Retreiving comply bitrock installer from s3.."
                 aws s3 cp s3://comply-ci/comply.linux-6.2.1.run ./comply.linux-6.2.1.run
                 chmod 755 ./comply.linux-6.2.1.run
                 echo "------------------- Executing comply.linux-6.2.1.run"
                 echo "----------------------------------------------------"
                 ./comply.linux-6.2.1.run --mode unattended --optionfile ./install.options
                 echo "------------------- Executing ./worldspace/bin/db_upgrade.sh"
                 echo "------------------------------------------------------------"
                 ./worldspace/bin/db_upgrade.sh
                 sed -i 's-^/opt/worldspace/components/keycloak/bin/standalone.sh-nohup /opt/worldspace/components/keycloak/bin/standalone.sh-g' /opt/worldspace/components/keycloak/bin/firstrun.sh
                 sed -i 's/OVERWRITE_EXISTING$/OVERWRITE_EXISTING \&/g' /opt/worldspace/components/keycloak/bin/firstrun.sh
                 echo "------------------- Executing ./worldspace/components/keycloak/bin/firstrun.sh"
                 echo "------------------------------------------------------------------------------"
                 chown -R worldspace:worldspace /opt/worldspace
                 ./worldspace/components/keycloak/bin/firstrun.sh &
                 cd -;
                 echo "------------------- Executing /etc/supervisord.d/comply.ini edits... ---------"
                 echo "------------------------------------------------------------------------------"
                 cat scripts/components/core-init-edit.txt | while read p n; do sed -i "/$p/,+$n"d"" /etc/supervisord.d/comply.ini; done
                 sed -i 's/autostart=false/autostart=true/g' /etc/supervisord.d/comply.ini
                 echo "------------------ Check supervisorctl service status ------------------------"
                 echo "------------------------------------------------------------------------------"
                 supervisorctl reload
                 supervisorctl status
                 systemctl restart nginx
#                 ./start_order.sh core
                 ;;

        "selenium" )
                     mkdir /opt/worldspace
#                     cp scripts/components/install.options.selenium /opt/install.options
                     cp -Ra ./scripts/components/sslcerts /opt
#                     cp ./scripts/comply.linux-6.2.1.run /opt
                     cd /opt;
                     echo "Retreiving comply install.options from s3.."
                     aws s3 cp s3://comply-ci/install.options.selenium ./install.options
                     echo "Retreiving comply bitrock installer from s3.."
                     aws s3 cp s3://comply-ci/comply.linux-6.2.1.run ./comply.linux-6.2.1.run
                     chmod 755 ./comply.linux-6.2.1.run
                     echo "------------------- Executing comply.linux-6.2.1.run"
                     echo "----------------------------------------------------"
                     ./comply.linux-6.2.1.run --mode unattended --optionfile ./install.options
#                     ./worldspace/bin/db_upgrade.sh
#                     ./worldspace/components/keycloak/bin/firstrun.sh
                     chown -R worldspace:worldspace /opt/worldspace
                     cd -;
                     echo "------------------- Executing /etc/supervisord.d/comply.ini edits..."
                     echo "------------------------------------------------------------------------------"
                     cat scripts/components/selenium-init-edit.txt | while read p n; do sed -i "/$p/,+$n"d"" /etc/supervisord.d/comply.ini; done
                     sed -i 's/autostart=false/autostart=true/g' /etc/supervisord.d/comply.ini
                     echo "------------------ Check supervisorctl service status ------------------------"
                     echo "------------------------------------------------------------------------------"
                     supervisorctl reload
                     supervisorctl status
 #                    start_order.sh selenium
                     ;;
        esac

fi

